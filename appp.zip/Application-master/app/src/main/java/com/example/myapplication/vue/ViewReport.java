package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Report;
import com.example.myapplication.outils.MesOutils;
import com.example.testprojet.R;
import com.squareup.picasso.Picasso;

public class ViewReport extends AppCompatActivity {

    //proprietes
    private RelativeLayout relative;
    private TextView titletxt;
    private TextView adresstxt;
    private TextView usernametxt;
    private TextView desctxt;
    private TextView reportcomment;
    private TextView datetxt;
    private ImageView imagereport;
    private ImageView reportcommentimage;
    private Controle controler;
    private Report report;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_report);

        init();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_delete,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        /*if(item.getItemId()==R.id.delete){
            Intent intent = new Intent(this, HomePage.class);
            //notifyDataSetChanged();
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            // Add new Flag to start new Activity
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            controler.delReport(report);
            controler.mesRapports.clear();
            controler.all();
            controler.mine(controler.USER);
            Toast.makeText(ViewReport.this,"Report deleted",Toast.LENGTH_LONG).show();
        }*/
        return super.onOptionsItemSelected(item);
    }

    /**
     * initialization des liens avec les objet
     */
    private void init(){
        relative = findViewById(R.id.relative);
        titletxt = findViewById(R.id.titletxt);
        adresstxt = findViewById(R.id.adresstxt);
        usernametxt = findViewById(R.id.usernametxt);
        desctxt = findViewById(R.id.desctxt);
        reportcomment = findViewById(R.id.reportcomment);
        datetxt = findViewById(R.id.datetxt);
        imagereport = findViewById(R.id.imagereport);
        reportcommentimage = findViewById(R.id.reportcommentimage);
        relative = findViewById(R.id.relative);
        this.controler = Controle.getInstance(this);
        recupProfil();
    }
    public void recupProfil(){
        if(controler.getTitle()!=""){
            usernametxt.setText("shared by "+controler.USER);
            adresstxt.setText(controler.getAdress());
            titletxt.setText(controler.getTitle());
            desctxt.setText(controler.getDescription());
            if(!controler.getCommentImage().equals("null"))
            reportcomment.setText(controler.getComment());
            if(controler.getImage()!=null)
                Picasso.get().load(controler.getImage()).resize(1000,1700).into(imagereport);
            if(controler.getCommentImage()!=null)
                Picasso.get().load(controler.getCommentImage()).resize(1000,1700).into(reportcommentimage);
            datetxt.setText(MesOutils.convertDateToString(controler.getDate1()));
            Integer etat = controler.getEtat();
            if(etat==1)relative.setBackgroundResource(R.drawable.red2);
            else if(etat==2)relative.setBackgroundResource(R.drawable.orange);
            else relative.setBackgroundResource(R.drawable.green2);
            // remettre à vide le rapport au control
            report = this.controler.report;
            controler.setReport(null);
        }
    }

    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, ListReports.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
        finish();
    }
}
