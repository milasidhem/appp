package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

import java.util.Calendar;

public class Registre extends AppCompatActivity {

    EditText name;
    EditText lastname;
    DatePicker calender;
    EditText adress;
    EditText phone;
    EditText email;
    EditText username;
    EditText password;
    EditText passwordconfirm;
    Controle controle;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registre);
        //Get that instance saved in the previous activity
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        init();
    }


    public void init() {
        name = findViewById(R.id.nametxt);
        lastname = findViewById(R.id.lastnametxt);
        adress = findViewById(R.id.adresstxt);
        phone = findViewById(R.id.phonetxt);
        email = findViewById(R.id.emailtxt);
        username = findViewById(R.id.usernametxt);
        password = findViewById(R.id.passwordtxt);
        passwordconfirm = findViewById(R.id.confirmpasswordtxt);
        calender = findViewById(R.id.dateN);
        this.controle = Controle.getInstance(this);
        controle.mesRapports.clear();
    }


    public void registre(View v){
        if(v==findViewById(R.id.registrebtn)){
            Log.d("message","********************* registre");
            String name = "";
            String lastname = "";
            String dateN = "";
            String adress = "";
            String phone = "";
            String email = "";
            String username = "";
            String password = "";
            String passwordconfirm = "";
            if(!this.name.getText().toString().isEmpty())
                name = this.name.getText().toString();
            //Toast.makeText(this," ff " + name, Toast.LENGTH_LONG).show();
            if(!this.lastname.getText().toString().isEmpty())
                lastname = this.lastname.getText().toString();
            dateN = calender.getYear()+"-"+ (calender.getMonth() + 1)+"-"+calender.getDayOfMonth();
            //Toast.makeText(this," +++++++++++++ " + dateN, Toast.LENGTH_LONG).show();
            if(!this.adress.getText().toString().isEmpty())
                adress = this.adress.getText().toString();
            if(!this.phone.getText().toString().isEmpty())
                phone = this.phone.getText().toString();
            if(!this.email.getText().toString().isEmpty())
                email = this.email.getText().toString();
            if(!this.username.getText().toString().isEmpty())
                username = this.username.getText().toString();
            if(!this.password.getText().toString().isEmpty())
                password = this.password.getText().toString();
            if(!this.passwordconfirm.getText().toString().isEmpty())
                passwordconfirm = this.passwordconfirm.getText().toString();
            if(name.equals("")||lastname.equals("")||dateN.equals("")||adress.equals("")||phone.equals("")||email.equals("")||lastname.equals("")||
                    password.equals("")||passwordconfirm.equals("")){
                Toast.makeText(Registre.this,"Saisir Inccorect",Toast.LENGTH_LONG).show();
            }
            else if(!isValidMobile(phone)){
                this.phone.setError("Type phone number again");
            }
            else if(!isValidMail(email)){
                this.email.setError("Type email again");
            }
            else if(getAge(calender.getYear(),(calender.getMonth() + 1),calender.getDayOfMonth())<18){
                Toast.makeText(Registre.this,"Age not allowed",Toast.LENGTH_LONG).show();
            }
            else if(!this.password.getText().toString().equals(this.passwordconfirm.getText().toString())){
                this.password.setError("Type password again");
                this.passwordconfirm.setError("");
            }
            else{
                controle.creeUser(name,lastname,dateN,adress,phone,email,username,password);
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {public void run() { signin(); }},1000);
            }
        }
        else if(v==findViewById(R.id.logg)){
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
            finish();
        }
    }

    private Integer getAge(int year, int month, int day){
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.set(year, month, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }

        Integer ageInt = new Integer(age);
        //String ageS = ageInt.toString();
        return ageInt;
    }

    private void signin(){
        if(!this.controle.EXISTS.contentEquals("exists")){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            String username = this.username.getText().toString();
            editor.putBoolean("visitor", true);
            editor.apply();
            Intent intent = new Intent(this, HomePage.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
            int reqCode = 1;
            Intent intentt = new Intent(this, HomePage.class);
            showNotification(this, "Notice", "Thanks for joining our comunity\r\nYour information will be reviewed\nUntil then you can enjoy the Guest Mode only", intentt, reqCode);
            finish();
        }
        else
            Toast.makeText(this,"change username please",Toast.LENGTH_LONG).show();
    }
    /**
     * Validation of phone Number
     */
    private boolean isValidMobile(String phone) {
        return android.util.Patterns.PHONE.matcher(phone).matches();
    }

    /**
     * Validation of email
     */
    private boolean isValidMail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
    boolean dbl = false;

    @Override
    public void onBackPressed() {
        if (dbl) {
            moveTaskToBack(true);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);super.onBackPressed();
            return;
        }

        this.dbl = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                dbl=false;
            }
        }, 2000);
    }

    /**
     *
     * @param context
     * @param title  --> title to show
     * @param message --> details to show
     * @param intent --> What should happen on clicking the notification
     * @param reqCode --> unique code for the notification
     */
    public void showNotification(Context context, String title, String message, Intent intent, int reqCode) {
        //SharedPreferenceManager sharedPreferenceManager = SharedPreferenceManager.getInstance(context);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, reqCode, intent, PendingIntent.FLAG_ONE_SHOT);
        String CHANNEL_ID = "channel_name";// The id of the channel.
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher_mine)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(message))
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channel Name";// The user-visible name of the channel.
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            notificationManager.createNotificationChannel(mChannel);
        }
        notificationManager.notify(reqCode, notificationBuilder.build()); // 0 is the request code, it should be unique id

        Log.d("showNotification", "showNotification: " + reqCode);
    }
}
