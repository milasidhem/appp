package com.example.myapplication.vue;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Announce;
import com.example.myapplication.model.Report;
import com.example.testprojet.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Collections;

public class HomePage extends AppCompatActivity {

    private BottomNavigationView navigation;
    private Controle controle;
    SharedPreferences sharedpreferences;
    String username;
    boolean visitor;
    private SwipeRefreshLayout swipeRefreshLayout;
    ImageView visipic, exit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        this.controle = Controle.getInstance(this);
        visipic = findViewById(R.id.mode_visitor);
        exit = findViewById(R.id.exit_mode);
        sharedpreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        username = sharedpreferences.getString("username", null);
        visitor = sharedpreferences.getBoolean("visitor", false);
        if(!visitor){
            visipic.setVisibility(View.GONE);
            exit.setVisibility(View.GONE);
        }
        else{
            visipic.setVisibility(View.VISIBLE);
            exit.setVisibility(View.VISIBLE);
        }
        controle.USER = username;
        controle.mine(controle.USER);
        controle.all();
        controle.announce();
        creerListeA();
        //creerListeN();
        navigation = findViewById(R.id.bottom_navigation);
        navigation.setOnNavigationItemSelectedListener(navi);
        swipeRefreshLayout = findViewById(R.id.swiperefresh);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
                overridePendingTransition(0, 0);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefreshLayout.setRefreshing(false);
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    }
                },500);
            }
        });
       //int reqCode = 1;
        //Intent intent = new Intent(this, WriteReport.class);
        //showNotification(this, "test", "sup nigga", intent, reqCode);
    }

    @Override
    protected void onResume(){
        super.onResume();
        //Toast.makeText(this,"Welcome "+username,Toast.LENGTH_LONG).show();
        controle.mine(username);
    }

    /**
     * créer la liste adapter
     */
    private void creerListeA(){
        ArrayList<Announce> mesAnnounces = controle.getMesAnnounces();
        //Collections.sort(mesAnnounces, Collections.<Announce>reverseOrder());
        if(mesAnnounces != null){
            LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
            RecyclerView lsAnc = findViewById(R.id.list_announce);
            lsAnc.setLayoutManager(layoutManager);
            AnnounceListAdapter adapter = new AnnounceListAdapter(mesAnnounces,this);
            lsAnc.setAdapter(adapter);
        }
    }

    /*public void creerListeN(){
        ArrayList<Report> mesReports = controle.getLesRapports();
        Collections.sort(mesReports, Collections.<Report>reverseOrder());
        if(mesReports != null){
            LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
            RecyclerView lsAnc = findViewById(R.id.list_newest);
            lsAnc.setLayoutManager(layoutManager);
            LatestListAdapter adapter = new LatestListAdapter(mesReports,this);
            lsAnc.setAdapter(adapter);
        }
    }*/

    public void exit(View v){
        if(v==findViewById(R.id.exit_mode)){
            showAlertExit();
        }
    }
    public void news(View v){
        if(v==findViewById(R.id.news)){
            Intent intentA = new Intent(HomePage.this, Actualites.class);
            //intentM.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intentA);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }


    /**
     *
     * @param context
     * @param title  --> title to show
     * @param message --> details to show
     * @param intent --> What should happen on clicking the notification
     * @param reqCode --> unique code for the notification
     */
    public void showNotification(Context context, String title, String message, Intent intent, int reqCode) {
        //SharedPreferenceManager sharedPreferenceManager = SharedPreferenceManager.getInstance(context);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, reqCode, intent, PendingIntent.FLAG_ONE_SHOT);
        String CHANNEL_ID = "channel_name";// The id of the channel.
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher_mine)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channel Name";// The user-visible name of the channel.
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            notificationManager.createNotificationChannel(mChannel);
        }
        notificationManager.notify(reqCode, notificationBuilder.build()); // 0 is the request code, it should be unique id

        Log.d("showNotification", "showNotification: " + reqCode);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navi = new
            BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    switch (menuItem.getItemId()){
                        case R.id.write :
                            if(!visitor){
                            Intent intentW = new Intent(HomePage.this, WriteReport.class);
                            //intentW.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intentW);
                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                            }
                            else{
                                showAlert();
                            }
                            break;
                        case R.id.search :
                            if(controle.limit==0){
                                Toast.makeText(HomePage.this,"no reports to show",Toast.LENGTH_LONG).show();
                            }
                            else {
                                Intent intentS = new Intent(HomePage.this, MapsActivity.class);
                                startActivity(intentS);
                                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                            }
                            break;
                        case R.id.list:
                            if(!visitor) {
                                Intent intentL = new Intent(HomePage.this, ListReports.class);
                                //intentL.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intentL);
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                            }
                            else
                                showAlert();
                            break;
                        case R.id.manage :
                            if(!visitor) {
                                Intent intentM = new Intent(HomePage.this, ManageAccount.class);
                                //intentM.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intentM);
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                            }
                            else
                                showAlert();
                            break;
                    }
                    return false;
                }
            };

    public void showAlert(){
        androidx.appcompat.app.AlertDialog.Builder alert = new androidx.appcompat.app.AlertDialog.Builder(this);
        alert.setTitle("Confirmation");
        alert.setMessage("You're in guest mode.\nYou need to log in first to continue.");
        alert.setPositiveButton("Log", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //discard
                Intent delete = new Intent(HomePage.this,Login.class);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putBoolean("visitor", false);
                editor.apply();
                startActivity(delete);
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                finish();
            }
        });
        alert.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        alert.create().show();
    }
    public void showAlertExit(){
        androidx.appcompat.app.AlertDialog.Builder alert = new androidx.appcompat.app.AlertDialog.Builder(this);
        alert.setTitle("Confirmation");
        alert.setMessage("Do you want to exit guest mode?");
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //discard
                Intent delete = new Intent(HomePage.this,Login.class);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putBoolean("visitor", false);
                editor.apply();
                startActivity(delete);
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
                finish();
            }
        });
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        alert.create().show();
    }
    boolean dbl = false;
    @Override
    public void onBackPressed() {
        if (dbl) {
            moveTaskToBack(true);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
            return;
        }

        this.dbl = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                dbl=false;
            }
        }, 2000);
    }

}
