package com.example.myapplication.vue;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class Delete extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    String username, password;
    EditText passwordtxt;
    Controle controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        //controle.mine(controle.USER);
        //controle.all();
        //Get that instance saved in the previous activity
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        username = sharedPreferences.getString("username", null);
    }
    public void DeleteA(View v){
        if(v.getId()==R.id.deleteA){
            passwordtxt = findViewById(R.id.passwordtxt);
            password = passwordtxt.getText().toString();
            if(password.contentEquals("")){
                Toast.makeText(Delete.this,"Saisir incomplet",Toast.LENGTH_LONG).show();
            }
            else{
                showAlert();
                int j = sharedPreferences.getInt("key", 0);
                //Default is 0 so autologin is disabled
                if(j == 0){
                    this.controle = controle.getInstance(getApplicationContext());
                    this.controle.delUser(username,password);
                    Intent activity = new Intent(getApplicationContext(), Login.class);
                    startActivity(activity);
                    Toast.makeText(this,"Your acocunt has been deleted",Toast.LENGTH_LONG).show();
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                }
                else {
                }
            }
        }
   }

   public void showAlert(){
       AlertDialog.Builder alert = new AlertDialog.Builder(this);
       alert.setTitle("Confirmation");
       alert.setMessage("Are you sure you want to delete your account?");
       alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {
               SharedPreferences.Editor editor = sharedPreferences.edit();
               editor.putInt("key", 0);
               editor.apply();
           }
       });
       alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {
           }
       });
       alert.create().show();
   }
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, ManageAccount.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
        finish();
    }
}
