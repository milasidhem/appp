package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Report;
import com.example.testprojet.R;

import java.util.ArrayList;
import java.util.Collections;

public class Actualites extends AppCompatActivity {
    private Controle controle;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualites);
        this.controle = Controle.getInstance(this);
        controle.mine(controle.USER);
        controle.all();
        creerListeN();
        swipeRefreshLayout = findViewById(R.id.swiperefresh);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                finish();
                overridePendingTransition(0, 0);
                startActivity(getIntent());
                overridePendingTransition(0, 0);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefreshLayout.setRefreshing(false);
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    }
                },500);
            }
        });
    }


    public void creerListeN(){
        ArrayList<Report> mesReports = controle.getLesRapports();
        Collections.sort(mesReports, Collections.<Report>reverseOrder());
        if(mesReports != null){
            LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
            RecyclerView lsAnc = findViewById(R.id.list_newest);
            lsAnc.setLayoutManager(layoutManager);
            LatestListAdapter adapter = new LatestListAdapter(mesReports,this);
            lsAnc.setAdapter(adapter);
        }
    }

    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, HomePage.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
        finish();
    }
}
